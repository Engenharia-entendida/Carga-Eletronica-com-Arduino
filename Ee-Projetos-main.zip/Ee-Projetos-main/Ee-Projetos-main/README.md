# _*Ee-Projetos*_
---
 Projetos do canal **Engenharia entendida**. Todos os arquivos dos nossos projetos, estarão aqui.
 
 **Lista de projetos disponíveis:**
 - [x] Carga eletrônica
 - [ ] Estação de solda
 - [x] Fonte de bancada 2.0
 - [ ] Conversor buck
 - [ ] Conversor boost
 
---
[Acesse nosso canal no Youtube](https://www.youtube.com/channel/UCo7owkh5gzRegCj2A4SXLNw)

[Acesse nosso instagram](https://www.instagram.com/engenhariaentendida/)

[Acesse nosso grupo no Telegram](https://t.me/engenhariaentendida)

![Cópia de Icon Ee](https://user-images.githubusercontent.com/68485673/131291069-07fb34bd-2d43-48b0-824d-9d7db9af1200.png)

